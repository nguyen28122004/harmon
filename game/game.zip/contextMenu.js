const contextMenu = document.getElementById('contextMenu');
let contextTarget = null;

// Xử lý click chuột phải trên item
export function attachContextMenu(canvas, key, meta) {
    canvas.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        contextTarget = canvas;

        const pos = JSON.parse(canvas.dataset.position || '{}');
        const locked = canvas.dataset.locked === 'true';
        const ignoreClick = canvas.dataset.ignoreClick === 'true';

        contextMenu.innerHTML = `
            <button disabled>🔍 <b>${key}</b> — (${pos.x ?? 0}, ${pos.y ?? 0}) — Layer ${meta.layer ?? 1}</button>
            <button id="toggleLock">${locked ? '🔓 Mở khóa vị trí' : '🔒 Khóa vị trí'}</button>
            <button id="toggleClick">${ignoreClick ? '🖱️ Cho phép click trái' : '🚫 Bỏ qua click trái'}</button>
        `;

        contextMenu.style.left = `${e.pageX}px`;
        contextMenu.style.top = `${e.pageY}px`;
        contextMenu.style.display = 'block';
    });
}

// Click ngoài thì ẩn menu
window.addEventListener('click', () => {
    contextMenu.style.display = 'none';
});

// Xử lý các hành động trong menu
contextMenu.addEventListener('click', (e) => {
    if (!contextTarget) return;
    const id = e.target.id;

    if (id === 'toggleLock') {
        const isLocked = contextTarget.dataset.locked === 'true';
        contextTarget.dataset.locked = (!isLocked).toString();
        // Không đổi pointerEvents để vẫn cho phép chuột phải
    }

    if (id === 'toggleClick') {
        const ignoreClick = contextTarget.dataset.ignoreClick === 'true';
        contextTarget.dataset.ignoreClick = (!ignoreClick).toString();
        // Không đổi pointerEvents để chuột phải vẫn hoạt động
    }

    contextMenu.style.display = 'none';
});