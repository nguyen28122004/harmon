import { createCanvasItem, activeItems } from './logic.js';
import { items } from './items.js';
import { attachContextMenu } from './contextMenu.js';

const gameCanvas = document.getElementById('gameCanvas');
const sidebar = document.getElementById('sidebar');
export let isRestoring = false;

export function saveItemStates() {
    const itemStates = [];
    const itemsOnCanvas = gameCanvas.querySelectorAll('.game-item');

    itemsOnCanvas.forEach((item) => {
        const key = item.dataset.key;
        const position = JSON.parse(item.dataset.position || '{}');
        const zIndex = item.style.zIndex || '1';
        itemStates.push({ key, position, zIndex });
    });

    localStorage.setItem('gameItemStates', JSON.stringify(itemStates));
}

export function restoreItemStates() {
    isRestoring = true;

    gameCanvas.querySelectorAll('.game-item').forEach(item => item.remove());

    sidebar.innerHTML = '';
    activeItems.clear();

    const savedStates = JSON.parse(localStorage.getItem('gameItemStates') || '[]');
    const keysPlaced = new Set();

    savedStates.forEach(({ key, position }) => {
        if (items[key]) {
            const meta = items[key];
            const clone = createCanvasItem(key, meta, true, {}, position, {
                skipSidebarCheck: true
            });
            clone.dataset.position = JSON.stringify(position);
            clone.dataset.key = key;
            gameCanvas.appendChild(clone);
            activeItems.add(key);
            keysPlaced.add(key);
        }
    });

    for (const key in items) {
        if (!keysPlaced.has(key)) {
            const canvas = createCanvasItem(key, items[key]);
            canvas.id = 'sidebar-' + key;
            sidebar.appendChild(canvas);
        }
    }

    isRestoring = false;
}

export function resetItems() {
    const itemsOnCanvas = gameCanvas.querySelectorAll('.game-item');
    itemsOnCanvas.forEach(item => item.remove());
    localStorage.removeItem('gameItemStates');
    sidebar.innerHTML = '';

    for (const key in items) {
        const canvas = createCanvasItem(key, items[key]);
        canvas.id = 'sidebar-' + key;
        sidebar.appendChild(canvas);
    }

    activeItems.clear();
}